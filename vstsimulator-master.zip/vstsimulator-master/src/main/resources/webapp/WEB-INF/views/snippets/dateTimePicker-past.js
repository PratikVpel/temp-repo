$('.dateTimePicker').datetimepicker({
    dateFormat: 'yy-mm-dd'
    //, maxDateTime: new Date()
});