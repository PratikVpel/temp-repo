/*
 * SteVe - SteckdosenVerwaltung - https://github.com/vst-community/vst
 * Copyright (C) 2013-2023 SteVe Community Team
 * All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package com.vst.simulator.service;

import com.vst.simulator.VstException;
import com.vst.simulator.ocpp.ChargePointService12_Invoker;
import com.vst.simulator.ocpp.ChargePointService15_Invoker;
import com.vst.simulator.ocpp.ChargePointService16_Invoker;
import com.vst.simulator.ocpp.ChargePointService16_InvokerImpl;
import com.vst.simulator.ocpp.OcppVersion;
import com.vst.simulator.ocpp.task.ClearChargingProfileTask;
import com.vst.simulator.ocpp.task.GetCompositeScheduleTask;
import com.vst.simulator.ocpp.task.SetChargingProfileTask;
import com.vst.simulator.ocpp.task.TriggerMessageTask;
import com.vst.simulator.repository.ChargingProfileRepository;
import com.vst.simulator.repository.dto.ChargingProfile;
import com.vst.simulator.service.dto.EnhancedSetChargingProfileParams;
import com.vst.simulator.web.dto.ocpp.ClearChargingProfileParams;
import com.vst.simulator.web.dto.ocpp.GetCompositeScheduleParams;
import com.vst.simulator.web.dto.ocpp.SetChargingProfileParams;
import com.vst.simulator.web.dto.ocpp.TriggerMessageParams;
import lombok.extern.slf4j.Slf4j;
import ocpp.cp._2015._10.ChargingProfilePurposeType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 * @author Sevket Goekay <sevketgokay@gmail.com>
 * @since 13.03.2018
 */
@Slf4j
@Service
@Qualifier("ChargePointService16_Client")
public class ChargePointService16_Client extends ChargePointService15_Client {

    @Autowired private ChargePointService16_InvokerImpl invoker16;
    @Autowired private ChargingProfileRepository chargingProfileRepository;

    @Override
    protected OcppVersion getVersion() {
        return OcppVersion.V_16;
    }

    @Override
    protected ChargePointService12_Invoker getOcpp12Invoker() {
        return invoker16;
    }

    @Override
    protected ChargePointService15_Invoker getOcpp15Invoker() {
        return invoker16;
    }

    protected ChargePointService16_Invoker getOcpp16Invoker() {
        return invoker16;
    }

    // -------------------------------------------------------------------------
    // Multiple Execution - since OCPP 1.6
    // -------------------------------------------------------------------------

    public int triggerMessage(TriggerMessageParams params) {
        TriggerMessageTask task = new TriggerMessageTask(getVersion(), params);

        BackgroundService.with(executorService)
                         .forEach(task.getParams().getChargePointSelectList())
                         .execute(c -> getOcpp16Invoker().triggerMessage(c, task));

        return taskStore.add(task);
    }

    public int setChargingProfile(SetChargingProfileParams params) {
        ChargingProfile.Details details = chargingProfileRepository.getDetails(params.getChargingProfilePk());

        checkAdditionalConstraints(params, details);

        EnhancedSetChargingProfileParams enhancedParams = new EnhancedSetChargingProfileParams(params, details);
        SetChargingProfileTask task = new SetChargingProfileTask(getVersion(), enhancedParams, chargingProfileRepository);

        BackgroundService.with(executorService)
                         .forEach(task.getParams().getChargePointSelectList())
                         .execute(c -> getOcpp16Invoker().setChargingProfile(c, task));

        return taskStore.add(task);
    }

    public int clearChargingProfile(ClearChargingProfileParams params) {
        ClearChargingProfileTask task = new ClearChargingProfileTask(getVersion(), params, chargingProfileRepository);

        BackgroundService.with(executorService)
                         .forEach(task.getParams().getChargePointSelectList())
                         .execute(c -> getOcpp16Invoker().clearChargingProfile(c, task));

        return taskStore.add(task);
    }

    public int getCompositeSchedule(GetCompositeScheduleParams params) {
        GetCompositeScheduleTask task = new GetCompositeScheduleTask(getVersion(), params);

        BackgroundService.with(executorService)
                         .forEach(task.getParams().getChargePointSelectList())
                         .execute(c -> getOcpp16Invoker().getCompositeSchedule(c, task));

        return taskStore.add(task);
    }

    /**
     * Do some additional checks defined by OCPP spec, which cannot be captured with javax.validation
     */
    private static void checkAdditionalConstraints(SetChargingProfileParams params, ChargingProfile.Details details) {
        ChargingProfilePurposeType purpose = ChargingProfilePurposeType.fromValue(details.getProfile().getChargingProfilePurpose());

        if (ChargingProfilePurposeType.CHARGE_POINT_MAX_PROFILE == purpose
                && params.getConnectorId() != null
                && params.getConnectorId() != 0) {
            throw new VstException("ChargePointMaxProfile can only be set at Charge Point ConnectorId 0");
        }

        if (ChargingProfilePurposeType.TX_PROFILE == purpose
                && params.getConnectorId() != null
                && params.getConnectorId() < 1) {
            throw new VstException("TxProfile should only be set at Charge Point ConnectorId > 0");
        }

    }
}
