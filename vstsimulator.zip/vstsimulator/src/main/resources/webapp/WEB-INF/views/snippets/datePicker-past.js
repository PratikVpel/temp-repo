$('.datePicker').datepicker({
    dateFormat: 'yy-mm-dd',
    maxDate: new Date(),
    changeMonth: true,
    changeYear: true,
    yearRange: '-100:+0'
});