
package com.vst.simulator.config;

import com.vst.simulator.VstConfiguration;
import com.vst.simulator.VstProdCondition;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.oas.annotations.EnableOpenApi;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

import static springfox.documentation.builders.RequestHandlerSelectors.withClassAnnotation;

/**
 * @author Sevket Goekay <sevketgokay@gmail.com>
 * @since 15.09.2022
 */
@Configuration
@EnableOpenApi
@Conditional(VstProdCondition.class)
public class ApiDocsConfiguration {

    static {
        // Set the path with prefix /manager to protect the documentation behind regular sign-in
        // Default is just /v3/api-docs
        System.setProperty("springfox.documentation.open-api.v3.path", "/manager/v3/api-docs");
    }

    @Bean
    public Docket apiDocs() {
        String title = "VST REST API Documentation";

        var apiInfo = new ApiInfoBuilder()
            .title(title)
            .description(title)
            .license("GPL-3.0")
            .licenseUrl("https://github.com/vst-community/vst/blob/master/LICENSE.txt")
            .version(VstConfiguration.CONFIG.getVstVersion())
            .build();

        return new Docket(DocumentationType.OAS_30)
            .useDefaultResponseMessages(false)
            .apiInfo(apiInfo)
            .select()
            .apis(withClassAnnotation(RestController.class))
            .build();
    }
}
