/*
 * SteVe - SteckdosenVerwaltung - https://github.com/vst-community/vst
 * Copyright (C) 2013-2023 SteVe Community Team
 * All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package com.vst.simulator.ocpp;

import com.vst.simulator.ocpp.task.ChangeAvailabilityTask;
import com.vst.simulator.ocpp.task.ChangeConfigurationTask;
import com.vst.simulator.ocpp.task.ClearCacheTask;
import com.vst.simulator.ocpp.task.GetDiagnosticsTask;
import com.vst.simulator.ocpp.task.RemoteStartTransactionTask;
import com.vst.simulator.ocpp.task.RemoteStopTransactionTask;
import com.vst.simulator.ocpp.task.ResetTask;
import com.vst.simulator.ocpp.task.UnlockConnectorTask;
import com.vst.simulator.ocpp.task.UpdateFirmwareTask;
import com.vst.simulator.repository.dto.ChargePointSelect;

/**
 * @author Sevket Goekay <sevketgokay@gmail.com>
 * @since 20.03.2015
 */
public interface ChargePointService12_Invoker {

    void reset(ChargePointSelect cp, ResetTask task);

    void clearCache(ChargePointSelect cp, ClearCacheTask task);

    void getDiagnostics(ChargePointSelect cp, GetDiagnosticsTask task);

    void updateFirmware(ChargePointSelect cp, UpdateFirmwareTask task);

    void unlockConnector(ChargePointSelect cp, UnlockConnectorTask task);

    void changeAvailability(ChargePointSelect cp, ChangeAvailabilityTask task);

    void changeConfiguration(ChargePointSelect cp, ChangeConfigurationTask task);

    void remoteStartTransaction(ChargePointSelect cp, RemoteStartTransactionTask task);

    void remoteStopTransaction(ChargePointSelect cp, RemoteStopTransactionTask task);
}
